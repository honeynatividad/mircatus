MultiMerch Marketplace for OpenCart
==========

[MultiMerch Digital Marketplace for OpenCart](http://multimerch.com/) is now available on GitHub!

We'll be updating the readme and the docs shortly, meanwhile feel free to check it out and start fiddling with the code.
