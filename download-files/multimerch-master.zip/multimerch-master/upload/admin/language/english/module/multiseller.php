<?php
$_['heading_title'] = '<b>[MultiMerch] Digital Marketplace</b>';
?>
