<?php

// Heading
$_['heading_title'] = 'اجمالي الطلبات الخاصة بالباعة';

// Text
$_['text_view'] = 'المزيد ...';
