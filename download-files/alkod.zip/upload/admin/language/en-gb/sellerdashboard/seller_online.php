<?php
// Heading
$_['heading_title'] = 'Seller Online';

// Text
$_['text_view'] = 'View more...';
